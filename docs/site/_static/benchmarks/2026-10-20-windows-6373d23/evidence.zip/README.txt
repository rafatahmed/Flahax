Clean-checkout Benchmark v1 capture. Numerical failures are retained.
Paths identifying user home directories have been replaced with USER_HOME.
This changes path metadata and container bytes, not measurements or input hashes.
CHECKSUMS.sha256 covers these redistributed files, not the original local containers.
ASV JSON and logs remain the authoritative timing/failure records.
A failed scientific exit is intentional when a reference criterion is missed.
No physical validation or new live PHREEQC replay is included.
See manual-workflow.json for the hosted execution status. Earlier dispatch
errors, when present, are retained as historical logs.
